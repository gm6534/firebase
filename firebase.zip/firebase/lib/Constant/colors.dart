import 'package:flutter/material.dart';

const Color defaultcolor= Color.fromARGB(255, 10, 15, 32);
const Color primarycolor= Color.fromARGB(255, 75, 138, 163);
const Color backgroundcolor= Color.fromARGB(255, 226, 220,220);
const Color addbtncolor=Color.fromARGB(255, 245, 182, 177);
const Color textformfieldcolor=Color.fromARGB(255, 226, 226, 227);
const Color offwhite=Color.fromARGB(255, 241, 241, 245);